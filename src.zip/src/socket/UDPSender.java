package socket;

import java.net.*;
import java.util.Scanner;

public class UDPSender {
    public static void main(String[] args) {
        // Endereço IP e porta do servidor
        String serverIP = "127.0.0.1"; // Loopback para simular no mesmo computador
        int serverPort = 9876;

        try {
            // Cria um socket UDP
            DatagramSocket clientSocket = new DatagramSocket();

            // Obtém o endereço IP do servidor
            InetAddress serverAddress = InetAddress.getByName(serverIP);

            Scanner scanner = new Scanner(System.in);

            while (true) {
                // Lê a mensagem do usuário
                System.out.print("Digite uma mensagem para o servidor: ");
                String message = scanner.nextLine();

                // Converte a mensagem para bytes
                byte[] sendData = message.getBytes();

                // Cria o pacote para enviar ao servidor
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);

                // Envia o pacote ao servidor
                clientSocket.send(sendPacket);

                // Buffer para receber a resposta do servidor
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                // Recebe a resposta do servidor
                clientSocket.receive(receivePacket);
                String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println(response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}