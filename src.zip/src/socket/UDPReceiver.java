package socket;

import java.net.*;

public class UDPReceiver {
    public static void main(String[] args) {
        int port = 9876;

        try {
            DatagramSocket serverSocket = new DatagramSocket(port);
            System.out.println("Servidor iniciado. Aguardando mensagens...");

            while (true) {
                byte[] receiveData = new byte[1024];

                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                serverSocket.receive(receivePacket);
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Mensagem recebida do cliente: " + message);

                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                String response = "Resposta do servidor: Mensagem recebida!";
                byte[] sendData = response.getBytes();

                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                serverSocket.send(sendPacket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}