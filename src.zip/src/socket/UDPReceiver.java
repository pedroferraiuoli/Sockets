package socket;

import java.net.*;

public class UDPReceiver {
    public static void main(String[] args) {
        // Porta onde o servidor irá escutar
        int port = 9876;

        try {
            // Cria um socket UDP
            DatagramSocket serverSocket = new DatagramSocket(port);
            System.out.println("Servidor iniciado. Aguardando mensagens...");

            while (true) {
                // Buffer para receber dados
                byte[] receiveData = new byte[1024];

                // Pacote para receber dados
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                // Recebe o pacote do cliente
                serverSocket.receive(receivePacket);
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Mensagem recebida do cliente: " + message);

                // Obtém o endereço IP e a porta do cliente
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                // Prepara uma resposta
                String response = "Resposta do servidor: Mensagem recebida!";
                byte[] sendData = response.getBytes();

                // Envia a resposta ao cliente
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                serverSocket.send(sendPacket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}